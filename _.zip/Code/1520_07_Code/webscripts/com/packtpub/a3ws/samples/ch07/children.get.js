model.c = []
for each (c in companyhome.children) {
    model.c.push(c)
}